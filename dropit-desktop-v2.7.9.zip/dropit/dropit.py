#!/usr/bin/env python3
"""DropIt - beam files between your phone and PC over local WiFi.

No cloud, no USB cable, no accounts. Run it, open the shown address
(or scan the QR code) on your phone. Same WiFi required.

Usage:
    python dropit.py                 # serves on port 8000, saves to ~/DropIt
    python dropit.py --port 9000 --dir ./shared

Stdlib only for the core - no pip install needed. (QR codes appear
automatically if the `qrcode` package is installed.)
"""

import argparse
import html
import json
import mimetypes
import os
import re
import socket
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "2.7.9"

try:
    import qrcode  # noqa: F401
    HAS_QR = True
except ImportError:
    HAS_QR = False


# ------------------------------------------------------------ text notes
# Shared texts live in the app's own data dir (notes.json) -- NOT as files
# in the shared folder. The folder stays 100% the user's files.
_notes_lock = threading.Lock()

def _data_dir():
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        folder = os.path.join(base, "DropIt")
    else:
        folder = os.path.join(os.path.expanduser("~"), ".config", "DropIt")
    os.makedirs(folder, exist_ok=True)
    return folder

def _notes_path():
    return os.path.join(_data_dir(), "notes.json")

def load_notes():
    try:
        with open(_notes_path(), encoding="utf-8") as f:
            data = json.load(f)
        notes = [n for n in data
                 if isinstance(n, dict) and n.get("id") and isinstance(n.get("text"), str)]
        notes.sort(key=lambda n: n.get("created", 0))
        return notes
    except (OSError, ValueError):
        return []

def save_notes(notes):
    tmp = _notes_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(notes, f)
    os.replace(tmp, _notes_path())

def _new_note_id(notes):
    taken = {n.get("id") for n in notes}
    nid = "n%d" % int(time.time() * 1000)
    while nid in taken:
        nid += "1"
    return nid

def add_note(text):
    notes = load_notes()
    note = {"id": _new_note_id(notes), "text": text, "created": int(time.time())}
    notes.append(note)
    save_notes(notes)
    return note

def delete_note(nid):
    notes = load_notes()
    kept = [n for n in notes if n.get("id") != nid]
    if len(kept) == len(notes):
        return False
    save_notes(kept)
    return True

def migrate_snippets(directory):
    """One-time import of legacy snippet-*.txt files into the notes store."""
    try:
        names = sorted(os.listdir(directory))
    except OSError:
        return
    moved = []
    for name in names:
        ln = name.lower()
        if not (ln.startswith("snippet-") and ln.endswith(".txt")):
            continue
        path = os.path.join(directory, name)
        if not os.path.isfile(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                text = f.read().strip()
            m = re.match(r"snippet-(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})", name, re.I)
            if m:
                y, mo, d, h, mi, s = (int(g) for g in m.groups())
                created = int(time.mktime((y, mo, d, h, mi, s, 0, 0, -1)))
            else:
                created = int(os.path.getmtime(path))
            if text:
                moved.append((text, created))
            os.remove(path)
        except OSError:
            continue
    if moved:
        with _notes_lock:
            notes = load_notes()
            for text, created in moved:
                notes.append({"id": _new_note_id(notes), "text": text, "created": created})
            notes.sort(key=lambda n: n.get("created", 0))
            save_notes(notes)

PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DropIt</title>
<style>
  :root { --bg:#0a0d16; --card:#12172a; --card2:#1a2140; --line:#2a3560; --txt:#eef1f8;
          --muted:#8f99b8; --acc:#22d3ee; --acc2:#a78bfa; --good:#34d399; --bad:#fb7185; }
  * { box-sizing:border-box; margin:0; }
  body { background:radial-gradient(1100px 500px at 50% -10%, #16213d 0%, var(--bg) 55%) fixed, var(--bg);
         color:var(--txt); font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
         max-width:1320px; margin:0 auto; padding:26px 18px 70px; }
  .topbar { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px;
            flex-wrap:wrap; gap:10px; }
  .brand { display:flex; align-items:center; gap:13px; }
  .logo { width:46px; height:46px; border-radius:14px; background:linear-gradient(135deg,var(--acc),var(--acc2));
          display:flex; align-items:center; justify-content:center; font-size:25px;
          box-shadow:0 8px 24px rgba(56,189,248,.35); }
  .logoimg { width:46px; height:46px; border-radius:14px;
          box-shadow:0 8px 24px rgba(56,189,248,.35); }
  h1 { font-size:25px; letter-spacing:-.02em; }
  .ver { font-size:11px; color:var(--muted); border:1px solid var(--line); padding:3px 9px; border-radius:20px; }
  .status { display:flex; align-items:center; gap:8px; font-size:13px; color:var(--muted); }
  .dot { width:9px; height:9px; border-radius:50%; background:var(--good); box-shadow:0 0 12px var(--good);
         animation:pulse 2.2s infinite; }
  @keyframes pulse { 50% { opacity:.45; } }
  .copybtn { border:1px solid var(--line); background:var(--card2); color:var(--txt); border-radius:9px;
             padding:8px 14px; font-size:13px; cursor:pointer; white-space:nowrap; }
  .copybtn:hover { border-color:var(--acc); }
  .qr { text-align:center; }
  .qr img { width:136px; height:136px; border-radius:12px; background:#fff; padding:7px;
            border:1px solid var(--line); }
  .qr div { font-size:12px; color:var(--muted); margin-top:8px; }
  .hint { color:var(--muted); font-size:13px; margin-top:14px; line-height:1.55; }
  #drop { border:2px dashed var(--line); border-radius:14px; padding:28px 16px; text-align:center;
          cursor:pointer; transition:border-color .15s, background .15s; }
  #drop:hover { border-color:var(--acc2); }
  #drop.over { border-color:var(--acc); background:rgba(56,189,248,.07); transform:scale(1.005); }
  #drop .big { font-size:18px; font-weight:650; margin-bottom:8px; }
  #drop .small { color:var(--muted); font-size:13px; }
  #drop .small b { color:var(--txt); }
  #snippet { width:100%; background:#090c15; border:1px solid var(--line); border-radius:12px;
             color:var(--txt); padding:12px 14px; font-size:14px; font-family:inherit; resize:vertical; }
             resize:vertical; line-height:1.5; }
  #snippet:focus { outline:none; border-color:var(--acc); }
  #snippet::placeholder { color:var(--muted); }
  .snipcard { background:#090c15; border:1px solid var(--line); border-radius:14px;
              padding:14px 16px 14px 19px; margin-bottom:12px; position:relative; overflow:hidden; }
  .snipcard::before { content:""; position:absolute; left:0; top:0; bottom:0; width:3px;
              background:linear-gradient(180deg,var(--nac,var(--acc)),var(--nac2,var(--acc2))); }
  .snipcard:last-child { margin-bottom:0; }
  .sniphead { display:flex; align-items:center; gap:7px; font-size:12.5px; color:var(--muted); margin-bottom:9px; }
  .sniphead .who { color:var(--nac,var(--acc)); font-weight:700; }
  .sniptext { font-size:14.5px; line-height:1.55; white-space:pre-wrap; word-break:break-word;
              display:-webkit-box; -webkit-line-clamp:5; -webkit-box-orient:vertical; overflow:hidden; }
  .snipcard.expanded .sniptext { display:block; }
  .sniptext a { color:var(--acc); }
  .snipmore { background:none; border:none; color:var(--acc); font-size:13px; cursor:pointer;
              padding:5px 0 0; font-family:inherit; }
  .snipactions { display:flex; gap:8px; margin-top:11px; flex-wrap:nowrap; }
  .snipactions .btn { flex:1 1 0; min-width:0; padding:8px 4px; font-size:12.5px; white-space:nowrap; }
  #uploads { margin-top:14px; display:flex; flex-direction:column; gap:9px; }  .up { background:#090c15; border:1px solid var(--line); border-radius:11px; padding:11px 14px; font-size:14px; }
  .up .bar { height:6px; background:var(--line); border-radius:3px; margin-top:9px; overflow:hidden; }
  .up .bar > div { height:100%; width:0%; background:linear-gradient(90deg,var(--acc),var(--acc2)); transition:width .12s; }
  .up.done .bar > div { background:var(--good); }
  .up.err { color:var(--bad); }
  .frow { display:flex; align-items:center; gap:12px; padding:10px 8px; margin:0 -8px;
          border-top:1px solid var(--line); font-size:14px; border-radius:12px; transition:background .15s; }
  .frow:first-child { border-top:none; }
  .frow:hover { background:rgba(34,211,238,.05); }
  .thumb { width:54px; height:54px; object-fit:cover; border-radius:12px; flex:none;
          border:1px solid var(--line); background:#090c15; }
  .fic { font-size:20px; }
  .thwrap { position:relative; width:54px; height:54px; flex:none; }
  .thwrap .fic { display:flex; align-items:center; justify-content:center;
          width:54px; height:54px; border:1px solid var(--line); border-radius:12px; background:#090c15; }
  .tbadge { position:absolute; right:-6px; bottom:-6px; font-size:12px; line-height:1;
          background:#141a30; border:1px solid var(--line); border-radius:7px; padding:2px 3px; }
  .tbadge.tlabel { font-size:9px; font-weight:800; letter-spacing:.5px; padding:3px 5px; color:#7dd3fc; }
  .fmeta { flex:1 1 auto; min-width:0; display:flex; flex-direction:column; gap:3px; }
  .fname { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:600; font-size:13.5px; }
  .fsize { color:var(--muted); font-size:11.5px; white-space:nowrap; }
  .btn { border:1px solid var(--line); background:#090c15; color:var(--txt); border-radius:10px;
         padding:8px 14px; font-size:13px; cursor:pointer; text-decoration:none; white-space:nowrap;
         transition:border-color .15s, filter .15s; }
  .btn:hover { border-color:var(--acc); }
  .btn.primary { background:linear-gradient(135deg,var(--acc),var(--acc2)); border:none;
         color:#0a0f1e; font-weight:700; }
  .btn.primary:hover { filter:brightness(1.12); }
  .btn.danger:hover { border-color:var(--bad); color:var(--bad); }
  .empty { color:var(--muted); font-size:14px; padding:10px 4px; }
  .connectbar { display:flex; align-items:center; gap:8px; background:#090c15; border:1px solid var(--line);
         border-radius:999px; padding:6px 8px 6px 16px; }
  .connectbar a { color:var(--acc); font-weight:700; font-size:14px; text-decoration:none; word-break:break-all; }
  .connectwrap { display:flex; align-items:center; gap:10px; }
  .qrmini { background:#fff; border:1px solid var(--line); border-radius:10px; padding:4px;
            cursor:pointer; line-height:0; }
  .qrmini:empty { display:none; }
  .qrmini img { width:52px; height:52px; display:block; border-radius:6px; }
  .qrpop { display:none; margin:2px auto 14px; max-width:440px; text-align:center; }
  .qrpop.open { display:block; }
  .board { display:flex; flex-wrap:wrap; gap:14px; justify-content:center; align-items:stretch; }
  .col { background:linear-gradient(180deg,var(--card2),var(--card)); border:1px solid var(--line);
          border-radius:18px; padding:18px; box-shadow:0 12px 32px rgba(0,0,0,.35);
          position:relative; overflow:hidden; width:340px; max-width:100%; flex:0 0 auto;
          height:calc(100vh - 260px); min-height:360px; max-height:900px;
          display:flex; flex-direction:column; }
  .col::before { content:""; position:absolute; top:0; left:24px; right:24px; height:1px;
          background:linear-gradient(90deg,transparent,rgba(34,211,238,.55),rgba(167,139,250,.55),transparent); }
  .colhead { display:flex; align-items:center; gap:10px; margin-bottom:14px; flex-wrap:wrap; row-gap:8px; }
  .colhead h2 { font-size:12px; text-transform:uppercase; letter-spacing:.1em; color:var(--muted); }
  .count { font-size:11px; color:var(--muted); border:1px solid var(--line); background:#090c15;
           padding:2px 9px; border-radius:12px; }
  .count:empty { display:none; }
  .colbody { display:flex; flex-direction:column; gap:12px; flex:1; min-height:0; overflow-y:auto;
             padding-right:4px; scrollbar-width:thin; scrollbar-color:#2a3560 transparent; }
  .colbody::-webkit-scrollbar { width:8px; }
  .colbody::-webkit-scrollbar-thumb { background:#2a3560; border-radius:8px; }
  .colbody::-webkit-scrollbar-track { background:transparent; }
  .minicard { background:#090c15; border:1px solid var(--line); border-radius:14px; padding:16px; }
  .minicard h3 { font-size:13.5px; font-weight:650; margin-bottom:12px; }
  .folderedit { display:none; margin:-6px 0 14px; }
  .folderedit.open { display:block; }
  .folderedit .row { display:flex; gap:8px; }
  .folderedit input { flex:1; min-width:0; background:#090c15; border:1px solid var(--line);
    border-radius:9px; color:var(--txt); padding:8px 12px; font-size:13px; font-family:ui-monospace,Consolas,monospace; }
  .folderedit input:focus { outline:none; border-color:var(--acc); }
  .folderedit .cur { color:var(--muted); font-size:12px; margin-top:8px; word-break:break-all; }
  .folderedit .cur b { color:var(--txt); font-weight:600; }
  footer { text-align:center; color:var(--muted); font-size:12px; margin-top:26px; }
  .mtabs { display:none; }
  .viewer { display:none; position:fixed; inset:0; z-index:100; background:rgba(4,6,12,.93);
            align-items:center; justify-content:center; padding:18px; }
  .viewer.open { display:flex; }
  .vbox { width:100%; max-width:640px; max-height:88vh; max-height:88dvh; overflow:auto;
          background:var(--card); border:1px solid var(--line); border-radius:16px; padding:14px; }
  .vhead { display:flex; justify-content:space-between; align-items:center; gap:10px; margin-bottom:10px; }
  #vtitle { font-size:13px; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .vclose { background:#1a2036; border:1px solid var(--line); color:var(--txt); border-radius:10px;
            width:34px; height:34px; font-size:15px; cursor:pointer; flex:0 0 auto; }
  #vcontent img { max-width:100%; border-radius:10px; display:block; }
  #vcontent video { width:100%; border-radius:10px; background:#000; }
  #vcontent audio { width:100%; }
  #vcontent iframe { width:100%; height:70vh; border:none; border-radius:8px; background:#fff; }
  #vcontent pre { white-space:pre-wrap; word-break:break-word; font-size:13px; max-height:60vh;
                 overflow:auto; background:#090c15; border:1px solid var(--line);
                 border-radius:10px; padding:12px; }
  .docxview { text-align:left; line-height:1.65; font-size:15px; }
  .docxview h1,.docxview h2,.docxview h3,.docxview h4 { margin:.7em 0 .35em; line-height:1.3; }
  .docxview p { margin:.45em 0; }
  .docxview table.dx { border-collapse:collapse; margin:.7em 0; max-width:100%; }
  .docxview table.dx td { border:1px solid var(--line); padding:6px 9px; }
  .vrow { display:flex; align-items:center; gap:10px; padding:10px 4px; border-top:1px solid var(--line); }
  .vrow .fname { flex:1; }
  @media (max-width:720px){
    body { padding:16px 12px 104px; }
    .board { display:block; }
    .board .col { display:none; width:100%; margin:0;
             height:calc(100vh - 330px); height:calc(100dvh - 330px); min-height:340px; }
    .board .col.active { display:flex; }
    .qrpop.open { max-width:100%; }
    .mtabs { display:flex; position:fixed; left:0; right:0; bottom:0; z-index:60; gap:6px;
             background:rgba(9,12,21,.97); border-top:1px solid var(--line);
             padding:8px 10px calc(8px + env(safe-area-inset-bottom)); }
    .mtab { flex:1; display:flex; flex-direction:column; align-items:center; gap:3px; position:relative;
            background:none; border:none; color:var(--muted); font-size:11px; font-family:inherit;
            padding:8px 4px; border-radius:12px; cursor:pointer; }
    .mtab .mi { font-size:20px; }
    .mtab.sel { color:var(--txt); background:rgba(34,211,238,.1); }
    .mcount { position:absolute; top:2px; right:calc(50% - 28px); font-size:10px; background:var(--acc);
              color:#0a0f1e; font-weight:700; border-radius:10px; padding:1px 6px; }
    .mcount:empty { display:none; }
    .toast { bottom:calc(112px + env(safe-area-inset-bottom)); }
  }
  .toast { position:fixed; bottom:26px; left:50%; transform:translateX(-50%) translateY(20px); background:var(--card2);
           border:1px solid var(--acc); color:var(--txt); padding:11px 20px; border-radius:12px; font-size:14px;
           opacity:0; transition:.25s; pointer-events:none; z-index:120; max-width:92vw; text-align:center; }
  .toast.show { opacity:1; transform:translateX(-50%) translateY(0); }
</style>
</head>
<body>

<div class="topbar">
  <div class="brand">
    <img class="logoimg" src="/icon.png" alt="DropIt"
         onerror="this.remove();document.getElementById('logofallback').style.display='flex';">
    <div class="logo" id="logofallback" style="display:none">&#x1F4E5;</div>
    <div><h1>DropIt</h1></div>
    <span class="ver">v__VERSION__</span>
  </div>
  <div class="connectwrap">
    <div class="connectbar">
      <a href="__URL__">__URL__</a>
      <button class="copybtn" id="copy">Copy</button>
    </div>
    <button class="qrmini" id="qrtoggle" title="Show large QR code">__QRMINI__</button>
  </div>
  <div class="status"><span class="dot"></span>Running</div>
</div>
<div class="qrpop" id="qrpop">__QR__
  <p class="hint">Open the address on your phone &mdash; both devices need the same WiFi.<br>First run may ask for firewall permission &mdash; allow it.</p>
</div>

<div class="board">
  <div class="col" data-col="send">
    <div class="colhead"><h2>&#x1F4E4; Send</h2></div>
    <div class="colbody">
      <div class="minicard">
        <h3>Send files</h3>
        <div id="drop">
          <div class="big">Drop files here</div>
          <div class="small">or click to browse &mdash; they land in <b id="dirnamelabel">__DIRNAME__</b></div>
          <input type="file" id="picker" multiple style="display:none">
        </div>
        <div id="uploads"></div>
      </div>
      <div class="minicard">
        <h3>Send text</h3>
        <textarea id="snippet" rows="3" placeholder="Paste a link, email, phone number, or any text&#8230;"></textarea>
        <div style="display:flex;justify-content:flex-end;margin-top:10px;">
          <button class="btn primary" id="sendsnippet">Send text</button>
        </div>
      </div>
    </div>
  </div>
  <div class="col" data-col="notes">
    <div class="colhead"><h2>&#x1F4AC; Text notes</h2><span class="count" id="snipcount"></span></div>
    <div class="colbody"><div id="snips"><p class="empty">Loading&hellip;</p></div></div>
  </div>
  <div class="col" data-col="files">
    <div class="colhead"><h2>&#x1F4C1; Shared files</h2><span class="count" id="filecount"></span><span style="flex:1"></span>__DESKTOPBTNS__</div>
    __FOLDEREDIT__
    <div class="colbody"><div id="files"><p class="empty">Loading&hellip;</p></div></div>
  </div>
</div>

<nav class="mtabs">
  <button class="mtab sel" data-tab="send"><span class="mi">&#x1F4E4;</span><span>Send</span></button>
  <button class="mtab" data-tab="notes"><span class="mi">&#x1F4AC;</span><span>Notes</span><span class="mcount" id="mnotecount"></span></button>
  <button class="mtab" data-tab="files"><span class="mi">&#x1F4C1;</span><span>Files</span><span class="mcount" id="mfilecount"></span></button>
</nav>

<footer>DropIt &middot; local only &middot; no cloud, no accounts, no tracking</footer>
<div class="toast" id="toast"></div>
<div class="viewer" id="viewer"><div class="vbox">
  <div class="vhead"><span id="vtitle"></span><button class="vclose" id="vclose">&#x2715;</button></div>
  <div id="vcontent"></div>
</div></div>

<script>
const $ = s => document.querySelector(s);
const drop = $("#drop"), picker = $("#picker");
const esc = s => s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

function fmt(n){ if(n<1024) return n+" B"; if(n<1048576) return (n/1024).toFixed(1)+" KB";
  if(n<1073741824) return (n/1048576).toFixed(1)+" MB"; return (n/1073741824).toFixed(2)+" GB"; }
function iconFor(n){ const e=n.split(".").pop().toLowerCase();
  if(["png","jpg","jpeg","gif","webp","svg","heic","bmp"].includes(e)) return "🖼️";
  if(["mp4","mov","mkv","webm","avi","m4v"].includes(e)) return "🎬";
  if(["mp3","wav","flac","m4a","ogg","aac"].includes(e)) return "🎵";
  if(["zip","rar","7z","tar","gz"].includes(e)) return "📦";
  if(["pdf"].includes(e)) return "📕";
  if(["doc","docx","odt","rtf"].includes(e)) return "📘";
  if(["xls","xlsx","ods","csv"].includes(e)) return "📗";
  if(["ppt","pptx","odp"].includes(e)) return "📙";
  if(["html","htm","xml"].includes(e)) return "🌐";
  if(["py","js","ts","css","java","c","cpp","json"].includes(e)) return "💻";
  if(["txt","md","log"].includes(e)) return "📝";
  return "📄"; }
function badgeFor(n){
  if(/\\.(png|jpe?g|gif|webp|bmp|heic|svg)$/i.test(n)) return '<span class="tbadge">🖼️</span>';
  if(/\\.(mp4|mov|m4v|webm|mkv|avi)$/i.test(n)) return '<span class="tbadge">🎬</span>';
  if(/\\.(mp3|wav|flac|m4a|ogg|aac)$/i.test(n)) return '<span class="tbadge">🎵</span>';
  const p = n.split(".");
  const e = (p.length > 1 ? p.pop() : "file").toUpperCase().slice(0, 4);
  return '<span class="tbadge tlabel">' + esc(e) + '</span>';
}
function thumbFor(n){
  if(/\\.(png|jpe?g|gif|webp|bmp|heic|svg)$/i.test(n))
    return `<img class="thumb" loading="lazy" src="/thumb/${encodeURIComponent(n)}" alt="">`;
  if(/\\.(mp4|mov|m4v|webm|mkv|avi)$/i.test(n))
    return `<video class="thumb" preload="metadata" muted playsinline disablepictureinpicture src="/dl/${encodeURIComponent(n)}#t=0.5"></video>`;
  return `<span class="fic">${iconFor(n)}</span>`;
}
async function openFile(name){
  try {
    if(window.pywebview && window.pywebview.api && window.pywebview.api.open_file){
      const ok = await window.pywebview.api.open_file(name);
      if(!ok) toast("Couldn't open that file");
      return;
    }
  } catch(e){}
  location.href = "/dl/" + encodeURIComponent(name);
}
function toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show");
  clearTimeout(t._h); t._h=setTimeout(()=>t.classList.remove("show"),2200); }

// ---------- phone download cache: Download once, Open after ----------
function hasBridge(){ try{ return !!(window.pywebview && window.pywebview.api && window.pywebview.api.open_file); }catch(e){ return false; } }
const MEMBLOBS = {};
const DLSTATE = {};
try { Object.assign(DLSTATE, JSON.parse(localStorage.getItem("dropit_dl") || "{}")); } catch(e){}
function isDownloaded(f){ return DLSTATE[f.name] === f.size; }
function markDownloaded(f){ DLSTATE[f.name] = f.size;
  try{ localStorage.setItem("dropit_dl", JSON.stringify(DLSTATE)); }catch(e){} }
function dlLabel(f){ return (hasBridge() || isDownloaded(f)) ? "Open" : "Download"; }

const DBCACHE = {
  db:null,
  open(){ return new Promise((res, rej) => {
    if(this.db) return res(this.db);
    try{
      const rq = indexedDB.open("dropit-cache", 1);
      rq.onupgradeneeded = () => rq.result.createObjectStore("files");
      rq.onsuccess = () => { this.db = rq.result; res(this.db); };
      rq.onerror = () => rej(rq.error);
    }catch(e){ rej(e); }
  });},
  async get(name){ try{ const db = await this.open();
      return await new Promise((res, rej) => { const t = db.transaction("files").objectStore("files").get(name);
        t.onsuccess = () => res(t.result || null); t.onerror = () => rej(t.error); });
    }catch(e){ return null; } },
  async put(name, blob){ try{ const db = await this.open();
      await new Promise((res, rej) => { const t = db.transaction("files","readwrite").objectStore("files").put(blob, name);
        t.onsuccess = () => res(); t.onerror = () => rej(t.error); });
    }catch(e){} },
  async clear(){ try{ const db = await this.open();
      await new Promise((res, rej) => { const t = db.transaction("files","readwrite").objectStore("files").clear();
        t.onsuccess = () => res(); t.onerror = () => rej(t.error); });
    }catch(e){} }
};

async function ensureSpace(){
  try{
    const est = await navigator.storage.estimate();
    if(est.usage > 400*1024*1024){
      await DBCACHE.clear();
      for(const k in MEMBLOBS) delete MEMBLOBS[k];
      for(const k in DLSTATE) delete DLSTATE[k];
      try{ localStorage.setItem("dropit_dl", "{}"); }catch(e){}
    }
  }catch(e){}
}

let VURL = null;
function showViewer(title, html, url){
  closeViewer();
  $("#vtitle").textContent = title;
  $("#vcontent").innerHTML = html;
  $("#viewer").classList.add("open");
  VURL = url || null;
}
function closeViewer(){
  $("#viewer").classList.remove("open");
  $("#vcontent").innerHTML = "";
  if(VURL){ URL.revokeObjectURL(VURL); VURL = null; }
}
$("#vclose").onclick = () => closeViewer();
$("#viewer").onclick = e => { if(e.target.id === "viewer") closeViewer(); };

async function downloadFile(f, btn){
  if(btn){ if(btn.dataset.busy) return; btn.dataset.busy = "1"; btn.textContent = "\\u2026"; }
  try{
    toast("Downloading " + f.name);
    const r = await fetch("/dl/" + encodeURIComponent(f.name));
    if(!r.ok) throw 0;
    const blob = await r.blob();
    await ensureSpace();
    MEMBLOBS[f.name] = blob;
    DBCACHE.put(f.name, blob);
    markDownloaded(f);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = f.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    lastFilesSig = null; loadFiles();
    toast("Saved \\u2014 tap Open to view it");
  }catch(e){ toast("Download failed"); }
  if(btn){ delete btn.dataset.busy; btn.textContent = dlLabel(f); }
}

async function openBlob(f){
  let blob = MEMBLOBS[f.name] || await DBCACHE.get(f.name);
  if(!blob){ downloadFile(f); return; }
  MEMBLOBS[f.name] = blob;
  const n = f.name;
  if(/\\.(txt|md|log|json|csv|xml|html|css|js)$/i.test(n)){
    showViewer(n, `<pre>${esc((await blob.text()).slice(0, 30000))}</pre>`);
    return;
  }
  if(/\\.docx$/i.test(n)){
    showViewer(n, '<div style="text-align:center;opacity:.6;padding:24px">Opening document\\u2026</div>');
    try{
      const r = await fetch("/api/docx/?name=" + encodeURIComponent(n));
      if(!r.ok) throw 0;
      showViewer(n, '<div class="docxview">' + (await r.text()) + "</div>");
    }catch(e){
      showViewer(n, '<div style="text-align:center;opacity:.6;padding:24px">Couldn\\u2019t preview this Word file.</div>');
    }
    return;
  }
  const url = URL.createObjectURL(blob);
  if(/\\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(n))
    showViewer(n, `<img src="${url}" alt="">`, url);
  else if(/\\.(mp4|mov|m4v|webm|mkv|avi)$/i.test(n))
    showViewer(n, `<video src="${url}" controls autoplay playsinline style="width:100%">`, url);
  else if(/\\.(mp3|wav|flac|m4a|ogg|aac)$/i.test(n))
    showViewer(n, `<audio src="${url}" controls autoplay style="width:100%">`, url);
  else if(/\\.pdf$/i.test(n)){
    window.open(url, "_blank");
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  else openWithApp(n, blob, url);
}

async function openWithApp(n, blob, url){
  const file = new File([blob], n, { type: blob.type || "application/octet-stream" });
  if(navigator.share){
    try { await navigator.share({ files:[file] }); URL.revokeObjectURL(url); return; }
    catch(e){}
  }
  URL.revokeObjectURL(url);
  toast("Saved in Downloads \\u2014 open it from your Files app");
}

function fileTap(f, btn){
  if(hasBridge()){ openFile(f.name); return; }
  if(isDownloaded(f)) openBlob(f);
  else downloadFile(f, btn);
}

async function clearPhoneCache(){
  for(const k in MEMBLOBS) delete MEMBLOBS[k];
  for(const k in DLSTATE) delete DLSTATE[k];
  try{ localStorage.setItem("dropit_dl", "{}"); }catch(e){}
  await DBCACHE.clear();
}

function showSaved(){
  const names = Object.keys(DLSTATE);
  let html;
  if(!names.length) html = '<p class="empty">Nothing saved on this phone yet \\u2014 tap Download on any file.</p>';
  else html = names.map(n =>
      `<div class="vrow"><span class="fname" title="${esc(n)}">${esc(n)}</span>` +
      `<button class="btn primary" data-sopen="${esc(n)}">Open</button></div>`
    ).join("") +
    `<button class="btn danger" id="vclear" style="margin-top:12px;width:100%">Clear saved files</button>`;
  showViewer("Saved on this phone", html);
  document.querySelectorAll("[data-sopen]").forEach(b =>
    b.onclick = () => openBlob({ name: b.dataset.sopen, size: DLSTATE[b.dataset.sopen] }));
  const vc = $("#vclear");
  if(vc) vc.onclick = async () => {
    await clearPhoneCache(); closeViewer();
    lastFilesSig = null; loadFiles(); toast("Saved files cleared");
  };
}

$("#copy").onclick = async () => {
  const url = "__URL__";
  try { await navigator.clipboard.writeText(url); }
  catch(e){ const i=document.createElement("input"); i.value=url; document.body.appendChild(i);
    i.select(); document.execCommand("copy"); i.remove(); }
  toast("Link copied \\u2014 send it to your phone");
};

const qt = $("#qrtoggle"), qp = $("#qrpop");
if(qt && qp) qt.onclick = () => qp.classList.toggle("open");

const of = $("#openfolder");
if(of) of.onclick = () => {
  if(hasBridge()){ try { window.pywebview.api.open_folder(); } catch(e){} return; }
  showSaved();   // phone web: the "folder" is what DropIt saved on this phone
};

const cf = $("#changefolder");
if(cf){
  const fe = $("#folderedit"), fp = $("#folderpath");
  cf.onclick = () => { fp.value = fp.dataset.cur || ""; fe.classList.add("open"); fp.focus(); fp.select(); };
  $("#foldercancel").onclick = () => fe.classList.remove("open");
  $("#foldersave").onclick = async () => {
    const p = fp.value.trim();
    if(!p){ toast("Type a folder path first"); return; }
    try {
      const r = await window.pywebview.api.set_directory(p);
      if(r && r.ok){
        fp.dataset.cur = r.directory;
        $("#foldercur").textContent = r.directory;
        $("#dirnamelabel").textContent = r.dirname;
        fe.classList.remove("open");
        toast("Save folder changed");
        loadFiles();
      } else {
        toast("Couldn't use that folder: " + ((r && r.error) || "unknown error"));
      }
    } catch(e){ toast("Couldn't change the folder"); }
  };
}
if(cf && !hasBridge()) cf.style.display = "none";   // dead without the desktop bridge

drop.onclick = () => picker.click();
["dragover","dragenter"].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.add("over"); }));
["dragleave","drop"].forEach(e => drop.addEventListener(e, ev => { ev.preventDefault(); drop.classList.remove("over"); }));
drop.addEventListener("drop", ev => uploadFiles(ev.dataTransfer.files));
picker.addEventListener("change", () => { uploadFiles(picker.files); picker.value=""; });

function uploadFiles(files){
  [...files].forEach(f => {
    const row = document.createElement("div");
    row.className = "up";
    row.innerHTML = `<div>${esc(f.name)} <span style="color:var(--muted)">(${fmt(f.size)})</span></div><div class="bar"><div></div></div>`;
    $("#uploads").prepend(row);
    const bar = row.querySelector(".bar > div");
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload");
    xhr.upload.onprogress = ev => { if(ev.lengthComputable) bar.style.width = (ev.loaded/ev.total*100)+"%"; };
    xhr.onload = () => {
      if(xhr.status === 200){ row.classList.add("done"); bar.style.width="100%";
        toast("\\u2705 "+f.name+" received"); loadFiles(); }
      else { row.classList.add("err"); row.firstElementChild.textContent = "Upload failed: "+f.name; }
      setTimeout(()=>row.remove(), 4500);
    };
    xhr.onerror = () => { row.classList.add("err"); row.firstElementChild.textContent = "Upload failed: "+f.name; };
    const fd = new FormData(); fd.append("file", f);
    xhr.send(fd);
  });
}

$("#sendsnippet").onclick = async () => {
  const ta = $("#snippet"), text = ta.value.trim();
  if(!text){ toast("Type something first"); return; }
  try {
    const r = await fetch("/api/snippet", {method:"POST",
      headers:{"Content-Type":"application/json"}, body:JSON.stringify({text})});
    const j = await r.json();
    if(j.ok){ ta.value=""; toast("\u2705 Text shared"); loadNotes(); }
    else toast("Couldn't share that text");
  } catch(e){ toast("Couldn't share that text"); }
};

const NOTES = {};
function noteTime(ts){
  return new Date(ts*1000).toLocaleString([], {month:"short", day:"numeric", hour:"numeric", minute:"2-digit"});
}
async function copyNote(id){
  try {
    await navigator.clipboard.writeText(NOTES[id] || "");
    toast("Text copied");
  } catch(e){ toast("Couldn't copy text"); }
}
async function delNote(id){
  if(!confirm("Delete this text note?")) return;
  await fetch("/api/notes/delete", {method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({id})});
  loadNotes(); toast("Note deleted");
}
async function dlNote(id){
  const t = NOTES[id] || "";
  try {
    if(window.pywebview && window.pywebview.api && window.pywebview.api.save_note){
      const r = await window.pywebview.api.save_note({id, text: t});
      toast(r && r.ok ? "Note saved" : "Download cancelled");
      return;
    }
  } catch(e){}
  location.href = "/api/notes/dl?id=" + encodeURIComponent(id);
}
function linkify(s){
  return s.replace(/(https?:\\/\\/[^\\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
}

let lastFilesSig = null;
async function loadFiles(){
  const box = $("#files");
  try {
    const r = await fetch("/api/files"); const files = await r.json();
    const sig = files.map(f => f.name + "|" + f.size).join(";");
    if(sig === lastFilesSig) return;   // unchanged: skip re-render so video thumbs never flicker
    lastFilesSig = sig;
    $("#filecount").textContent = files.length || "";
    $("#mfilecount").textContent = files.length || "";
    if(!files.length){ box.innerHTML = '<p class="empty">Nothing here yet &mdash; beam something over from your phone.</p>'; return; }
    box.innerHTML = files.map((f,i) =>
      `<div class="frow"><span class="thwrap">${thumbFor(f.name)}${badgeFor(f.name)}</span>` +
      `<span class="fmeta"><span class="fname" title="${esc(f.name)}">${esc(f.name)}</span>` +
      `<span class="fsize">${fmt(f.size)}</span></span>` +
      `<button class="btn primary" data-dl="${i}">${dlLabel(f)}</button>` +
      `<button class="btn danger" data-del="${i}">Delete</button></div>`
    ).join("");
    box.querySelectorAll("[data-del]").forEach(b =>
      b.onclick = () => delFile(files[+b.dataset.del].name));
    box.querySelectorAll("[data-dl]").forEach(b =>
      b.onclick = () => fileTap(files[+b.dataset.dl], b));
  } catch(e){ box.innerHTML = '<p class="empty">Could not load file list.</p>'; }
}

const ACCENTS = [
  ["#22d3ee","#818cf8"], ["#a78bfa","#f472b6"], ["#f472b6","#fb7185"], ["#fbbf24","#fb923c"],
  ["#34d399","#22d3ee"], ["#60a5fa","#a78bfa"], ["#fb7185","#f472b6"], ["#a3e635","#34d399"]
];
function accentFor(id){ let h = 0; const s = String(id);
  for(let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return ACCENTS[h % ACCENTS.length]; }

async function loadNotes(){
  const snbox = $("#snips");
  try {
    const r = await fetch("/api/notes"); const notes = await r.json();
    $("#snipcount").textContent = notes.length || "";
    $("#mnotecount").textContent = notes.length || "";
    for(const k in NOTES) delete NOTES[k];
    if(!notes.length){ snbox.innerHTML = '<p class="empty">Nothing shared yet &mdash; send text from the Send column or your phone.</p>'; return; }
    snbox.innerHTML = notes.map(n => {
      NOTES[n.id] = n.text || "";
      const t = n.text || "(empty)";
      const long = t.split("\\n").length > 5 || t.length > 280;
      const ac = accentFor(n.id);
      return `<div class="snipcard" style="--nac:${ac[0]};--nac2:${ac[1]}">` +
      `<div class="sniphead"><span>&#x1F4AC;</span><span class="who">Text note</span>` +
      `<span>&middot;</span><span>${esc(noteTime(n.created))}</span></div>` +
      `<div class="sniptext">${linkify(esc(t))}</div>` +
      (long ? `<button class="snipmore">Show more</button>` : "") +
      `<div class="snipactions">` +
      `<button class="btn" data-copy="${esc(n.id)}">Copy</button>` +
      `<button class="btn" data-dl="${esc(n.id)}">Download</button>` +
      `<button class="btn danger" data-del="${esc(n.id)}">Delete</button></div></div>`;
    }).join("");
    snbox.querySelectorAll(".snipcard").forEach(card => {
      const more = card.querySelector(".snipmore");
      if(more) more.onclick = () => {
        const ex = card.classList.toggle("expanded");
        more.textContent = ex ? "Show less" : "Show more";
      };
      card.querySelector("[data-copy]").onclick = e => copyNote(e.target.dataset.copy);
      card.querySelector("[data-dl]").onclick = e => dlNote(e.target.dataset.dl);
      card.querySelector("[data-del]").onclick = e => delNote(e.target.dataset.del);
    });
  } catch(e){ snbox.innerHTML = '<p class="empty">Could not load text notes.</p>'; }
}

async function delFile(name){
  if(!confirm("Delete "+name+"?")) return;
  await fetch("/api/delete", {method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({name})});
  loadFiles(); toast("Deleted "+name);
}

const mtabs = document.querySelectorAll(".mtab");
function setTab(name){
  document.querySelectorAll(".board .col").forEach(c =>
    c.classList.toggle("active", c.dataset.col === name));
  mtabs.forEach(t => t.classList.toggle("sel", t.dataset.tab === name));
  try { localStorage.setItem("dropit_tab", name); } catch(e){}
}
mtabs.forEach(t => t.onclick = () => setTab(t.dataset.tab));
try { setTab(localStorage.getItem("dropit_tab") || "send"); } catch(e){ setTab("send"); }
loadFiles(); loadNotes(); setInterval(() => { loadFiles(); loadNotes(); }, 5000);
</script>
</body>
</html>
"""


def lan_ip() -> str:
    """Best-effort LAN IP without sending any traffic."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def asset_path(name: str):
    """Path to a bundled asset; works frozen (PyInstaller) and from source."""
    base = getattr(sys, "_MEIPASS", None)
    if base:
        for cand in (os.path.join(base, "assets", name), os.path.join(base, name)):
            if os.path.isfile(cand):
                return cand
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "assets", name), os.path.join(here, name)):
        if os.path.isfile(cand):
            return cand
    return None


_IMAGE_EXTS = {"png", "jpg", "jpeg", "gif", "webp", "bmp", "heic", "svg"}


def _is_image(name: str) -> bool:
    return name.rsplit(".", 1)[-1].lower() in _IMAGE_EXTS if "." in name else False


_THUMB_CACHE = {}


def _thumbnail(path: str):
    """Return (bytes, content_type) for a small preview of an image file."""
    try:
        key = (path, os.path.getmtime(path), os.path.getsize(path))
    except OSError:
        return None
    hit = _THUMB_CACHE.get(key)
    if hit:
        return hit
    data, ctype = None, "image/jpeg"
    try:
        from PIL import Image

        img = Image.open(path)
        img.thumbnail((384, 384), Image.LANCZOS)
        if img.mode in ("RGBA", "LA", "PA"):
            bg = Image.new("RGB", img.size, (10, 13, 22))
            bg.paste(img, mask=img.split()[-1])
            img = bg
        else:
            img = img.convert("RGB")
        import io

        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=72)
        data = buf.getvalue()
    except Exception:  # noqa: BLE001 - no PIL or unreadable: serve original
        try:
            with open(path, "rb") as f:
                data = f.read()
            ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        except OSError:
            return None
    if data is None:
        return None
    if len(_THUMB_CACHE) > 300:
        _THUMB_CACHE.clear()
    _THUMB_CACHE[key] = (data, ctype)
    return data, ctype


def safe_name(name: str) -> str:
    name = os.path.basename(name).strip()
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
    return name or "upload"


_DOCX_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def docx_to_html(path: str):
    """Convert a .docx file to simple sanitized HTML using only the stdlib.
    Returns the HTML string, or None if the file can't be read/parsed."""
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml")
        root = ET.fromstring(xml)
    except Exception:
        return None
    W = _DOCX_W
    body = root.find(W + "body")
    if body is None:
        return None

    def run_html(r):
        parts = []
        for n in r:
            if n.tag == W + "t":
                parts.append(html.escape(n.text or ""))
            elif n.tag == W + "tab":
                parts.append(" ")
            elif n.tag == W + "br":
                parts.append("<br>")
        t = "".join(parts)
        if not t.strip():
            return ""
        rpr = r.find(W + "rPr")
        if rpr is not None:
            if rpr.find(W + "b") is not None:
                t = "<b>" + t + "</b>"
            if rpr.find(W + "i") is not None:
                t = "<i>" + t + "</i>"
            if rpr.find(W + "u") is not None:
                t = "<u>" + t + "</u>"
        return t

    def para_html(p):
        inner = "".join(run_html(r) for r in p.findall(W + "r"))
        for hl in p.findall(W + "hyperlink"):
            inner += "".join(run_html(r) for r in hl.findall(W + "r"))
        return inner

    out = []
    for child in body:
        if child.tag == W + "p":
            ppr = child.find(W + "pPr")
            style, is_list = "", False
            if ppr is not None:
                ps = ppr.find(W + "pStyle")
                if ps is not None:
                    style = ps.get(W + "val", "") or ""
                is_list = ppr.find(W + "numPr") is not None
            inner = para_html(child)
            if not inner.strip():
                out.append("<p>&nbsp;</p>")
            elif style.startswith("Heading"):
                digits = "".join(c for c in style if c.isdigit())
                lvl = max(1, min(6, int(digits) if digits else 1))
                out.append("<h%d>%s</h%d>" % (lvl, inner, lvl))
            elif is_list:
                out.append("<p>&bull; " + inner + "</p>")
            else:
                out.append("<p>" + inner + "</p>")
        elif child.tag == W + "tbl":
            rows = []
            for tr in child.findall(W + "tr"):
                cells = []
                for tc in tr.findall(W + "tc"):
                    txt = " ".join(para_html(p) for p in tc.findall(W + "p"))
                    cells.append("<td>" + txt + "</td>")
                rows.append("<tr>" + "".join(cells) + "</tr>")
            out.append('<table class="dx">' + "".join(rows) + "</table>")
    return "".join(out)


def unique_path(directory: str, name: str) -> str:
    base, ext = os.path.splitext(name)
    candidate = os.path.join(directory, name)
    i = 1
    while os.path.exists(candidate):
        candidate = os.path.join(directory, f"{base} ({i}){ext}")
        i += 1
    return candidate


def parse_multipart(body: bytes, boundary: bytes):
    """Yield (filename, content) for file parts. Binary-safe."""
    files = []
    for part in body.split(b"--" + boundary):
        if part in (b"", b"--\r\n", b"--", b"\r\n"):
            continue
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"--"):
            part = part[:-2]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        head, sep, content = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        m = re.search(r'filename="([^"]*)"', head.decode("latin-1", "replace"))
        if m:
            files.append((safe_name(m.group(1)), content))
    return files


def qr_png(url: str) -> bytes:
    """PNG bytes of a QR code for url. Raises if qrcode/Pillow missing."""
    import io

    img = qrcode.make(url, box_size=8, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


class Handler(BaseHTTPRequestHandler):
    server_version = f"DropIt/{VERSION}"

    def log_message(self, fmt, *args):  # quieter logs
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # -- helpers ---------------------------------------------------------
    def _send(self, code, body: bytes, ctype="text/html; charset=utf-8", headers=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode(), "application/json",
                   {"Cache-Control": "no-store"})

    def _send_file(self, path, name, ctype, download=True):
        """Serve a file with Range support (video thumbnails, seeking)."""
        size = os.path.getsize(path)
        start, end, code = 0, size - 1, 200
        rh = self.headers.get("Range")
        if rh:
            m = re.match(r"bytes=(\d*)-(\d*)\s*$", rh)
            if m:
                s, e = m.groups()
                if s:
                    start = int(s)
                    end = int(e) if e else size - 1
                elif e:
                    start = max(0, size - int(e))
                end = min(end, size - 1)
                if 0 <= start <= end < size:
                    code = 206
                else:
                    start, end = 0, size - 1
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        if download:
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % name)
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            remaining = length
            while remaining > 0:
                chunk = f.read(min(65536, remaining))
                if not chunk:
                    break
                self.wfile.write(chunk)
                remaining -= len(chunk)

    # -- routes ----------------------------------------------------------
    def do_GET(self):
        if self.path == "/":
            qr_block = (
                '<div class="qr"><img src="/qr.png" alt="QR code">'
                "<div>Scan with your<br>phone camera</div></div>"
                if HAS_QR else ""
            )
            qr_mini = '<img src="/qr.png" alt="QR code">' if HAS_QR else ""
            desktop = getattr(self.server, "desktop", False)
            desktop_btns = (
                '<div style="display:flex;gap:8px;">'
                '<button class="btn" id="openfolder">&#x1F4C1; Open folder</button>'
                '<button class="btn" id="changefolder">Change...</button>'
                "</div>"
                if desktop else ""
            )
            folder_edit = (
                '<div class="folderedit" id="folderedit">'
                '<div class="row">'
                '<input id="folderpath" data-cur="__DIRPATH__" spellcheck="false" autocomplete="off">'
                '<button class="btn" id="foldersave">Save</button>'
                '<button class="btn" id="foldercancel">Cancel</button>'
                "</div>"
                '<div class="cur">Files currently land in <b id="foldercur">__DIRPATH__</b></div>'
                "</div>"
                if desktop else ""
            )
            page = (
                PAGE.replace("__VERSION__", VERSION)
                .replace("__URL__", html.escape(self.server.url))
                .replace("__DIRNAME__", html.escape(os.path.basename(self.server.directory)))
                .replace("__QR__", qr_block)
                .replace("__QRMINI__", qr_mini)
                .replace("__DESKTOPBTNS__", desktop_btns)
                .replace("__FOLDEREDIT__", folder_edit)
                .replace("__DIRPATH__", html.escape(self.server.directory))
            )
            self._send(200, page.encode(), headers={"Cache-Control": "no-store"})
        elif self.path == "/qr.png":
            try:
                self._send(200, qr_png(self.server.url), "image/png")
            except Exception:  # noqa: BLE001 - qrcode/Pillow not installed
                self._send(404, b"qr unavailable", "text/plain")
        elif self.path == "/icon.png":
            p = asset_path("icon.png")
            if p:
                with open(p, "rb") as f:
                    self._send(200, f.read(), "image/png")
            else:
                self._send(404, b"no icon", "text/plain")
        elif self.path.startswith("/thumb/"):
            name = safe_name(urllib.parse.unquote(self.path[len("/thumb/"):]))
            path = os.path.join(self.server.directory, name)
            if not os.path.isfile(path) or not _is_image(name):
                self._send(404, b"not found", "text/plain")
            else:
                made = _thumbnail(path)
                if made is None:
                    self._send(404, b"unreadable", "text/plain")
                else:
                    data, ctype = made
                    self._send(200, data, ctype)
        elif self.path == "/api/files":
            items = []
            for name in sorted(os.listdir(self.server.directory)):
                p = os.path.join(self.server.directory, name)
                if os.path.isfile(p):
                    items.append({"name": name, "size": os.path.getsize(p)})
            self._json(items)
        elif self.path == "/api/notes":
            with _notes_lock:
                notes = load_notes()
            self._json(notes)
        elif self.path == "/api/notes/dl" or self.path.startswith("/api/notes/dl?"):
            _, _, qs = self.path.partition("?")
            nid = ""
            for part in qs.split("&"):
                k, _, v = part.partition("=")
                if k == "id":
                    nid = urllib.parse.unquote(v)
            with _notes_lock:
                notes = load_notes()
            note = next((n for n in notes if n.get("id") == nid), None)
            if note is None:
                self._send(404, b"not found", "text/plain")
                return
            body = (note["text"] + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Content-Disposition",
                             'attachment; filename="shared-text-%s.txt"' % nid)
            self.end_headers()
            self.wfile.write(body)
        elif self.path.startswith("/api/docx/"):
            _, _, qs = self.path.partition("?")
            name = ""
            for part in qs.split("&"):
                k, _, v = part.partition("=")
                if k == "name":
                    name = urllib.parse.unquote(v)
            name = safe_name(name)
            if not name.lower().endswith(".docx"):
                self._send(404, b"not found", "text/plain")
                return
            fpath = os.path.join(self.server.directory, name)
            if not os.path.isfile(fpath):
                self._send(404, b"not found", "text/plain")
                return
            converted = docx_to_html(fpath)
            if not converted:
                self._send(500, b"cannot preview", "text/plain")
                return
            self._send(200, converted.encode("utf-8"), "text/html; charset=utf-8")
        elif self.path.startswith("/dl/"):
            name = safe_name(urllib.parse.unquote(self.path[len("/dl/"):]))
            path = os.path.join(self.server.directory, name)
            if not os.path.isfile(path):
                self._send(404, b"not found", "text/plain")
                return
            ctype = mimetypes.guess_type(name)[0] or "application/octet-stream"
            self._send_file(path, name, ctype)
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        ctype = self.headers.get("Content-Type") or ""

        if self.path == "/api/upload" and "multipart/form-data" in ctype:
            m = re.search(r"boundary=([^;]+)", ctype)
            if not m or length <= 0:
                self._json({"ok": False, "error": "bad request"}, 400)
                return
            body = self.rfile.read(length)
            saved = []
            for filename, content in parse_multipart(body, m.group(1).encode()):
                dest = unique_path(self.server.directory, filename)
                with open(dest, "wb") as f:
                    f.write(content)
                saved.append(os.path.basename(dest))
                self.log_message("saved %s (%d bytes)", dest, len(content))
            self._json({"ok": True, "saved": saved})
        elif self.path == "/api/delete":
            try:
                data = json.loads(self.rfile.read(length) or b"{}")
                name = safe_name(data.get("name", ""))
                path = os.path.join(self.server.directory, name)
                if os.path.isfile(path):
                    os.remove(path)
                    self._json({"ok": True})
                else:
                    self._json({"ok": False}, 404)
            except (json.JSONDecodeError, OSError):
                self._json({"ok": False}, 400)
        elif self.path == "/api/snippet":
            # Share a text note. Stored in the app's notes.json (app data dir),
            # NOT as a file in the shared folder.
            try:
                data = json.loads(self.rfile.read(length) or b"{}")
                text = data.get("text", "")
                if not isinstance(text, str) or not text.strip():
                    self._json({"ok": False, "error": "empty"}, 400)
                    return
                text = text.strip()
                if len(text) > 100_000:
                    self._json({"ok": False, "error": "too long (100k chars max)"}, 400)
                    return
                with _notes_lock:
                    note = add_note(text)
                self.log_message("note %s (%d chars)", note["id"], len(text))
                self._json({"ok": True, "id": note["id"], "name": note["id"]})
            except (json.JSONDecodeError, OSError):
                self._json({"ok": False}, 400)
        elif self.path == "/api/notes/delete":
            try:
                data = json.loads(self.rfile.read(length) or b"{}")
                nid = data.get("id", "")
                with _notes_lock:
                    ok = delete_note(nid) if isinstance(nid, str) and nid else False
                self._json({"ok": ok}, 200 if ok else 404)
            except (json.JSONDecodeError, OSError):
                self._json({"ok": False}, 400)
        else:
            self._send(404, b"not found", "text/plain")


def make_server(port: int, directory: str, desktop: bool = False) -> ThreadingHTTPServer:
    os.makedirs(directory, exist_ok=True)
    migrate_snippets(os.path.abspath(directory))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    server.url = f"http://{lan_ip()}:{port}"
    server.directory = os.path.abspath(directory)
    server.desktop = desktop
    server.daemon_threads = True
    return server


def main():
    ap = argparse.ArgumentParser(description="DropIt - beam files phone <-> PC over WiFi")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--dir", default=os.path.join(os.path.expanduser("~"), "DropIt"))
    args = ap.parse_args()

    server = make_server(args.port, args.dir)

    print(f"\n  DropIt {VERSION} running!")
    print(f"  On your phone, open:  {server.url}")
    print(f"  Files land in:        {server.directory}")
    print("  Stop with Ctrl+C\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBye!")


if __name__ == "__main__":
    main()
